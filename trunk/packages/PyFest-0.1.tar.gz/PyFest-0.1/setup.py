from distutils.core import setup

setup(	name='PyFest',
	version='0.1',
	author='Chris King',
	author_email='squirrel@wpi.edu',
	download_url='http://squirrel.isa-geek.org/programs/download/',
	long_description='A simple interface to the Festival speech server.',
	py_modules=['festival'])
